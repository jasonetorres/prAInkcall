<img src="{{ asset('images/prAInkcall.png') }}" alt="Application Logo" {{ $attributes }}>
